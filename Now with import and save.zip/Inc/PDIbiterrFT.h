/////////////////////////////////////////////////////////////////////
// Polhemus Inc., www.polhemus.com
// � 2002-2011 Polhemus Inc., All Rights Reserved
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
//
//  Filename:           $Workfile: PDIbiterrFT.h $
//
//  Project Name:       Polhemus Tracker Command Interface API 
//
//  Original Author:    S. Gagnon
//
//  Description:        Interface for the CFTBITErr class
//
//  VSS $Header: /PiDevTools9/Inc/PDIbiterrFT.h 1     8/26/11 12:27p Suzanne $  
//
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
#ifndef _PDIBITERRFT_H_
#define _PDIBITERRFT_H_

class CFTBITErr;

/////////////////////////////////////////////////////////////////////
// CLASS CPDIbiterrFT
/////////////////////////////////////////////////////////////////////

class PDI_API CPDIbiterrFT
{
public:
	CPDIbiterrFT();
	virtual ~CPDIbiterrFT();

    VOID    Parse    ( LPTSTR szBuf, DWORD dwSize ) const;	// Parses BIT results into provided string buffer
	BOOL	IsClear	 ( VOID );

private:
	CPDIbiterrFT( const CPDIbiterrFT & );

	CFTBITErr * m_pFTB;

	friend class CPDIfastrak;
};

#endif