
// G4mfc.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CG4mfcApp:
// See G4mfc.cpp for the implementation of this class
//

class CG4mfcApp : public CWinAppEx
{
public:
	CG4mfcApp();

// Overrides
	public:
	virtual BOOL InitInstance();
	virtual BOOL OnIdle(LONG lCount);
	virtual int ExitInstance(); // return app exit code

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CG4mfcApp theApp;