
// G4mfc.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "G4mfc.h"
#include "G4mfcDlg.h"
//#include "LinkedList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CG4mfcApp

BEGIN_MESSAGE_MAP(CG4mfcApp, CWinAppEx)
	ON_COMMAND(ID_HELP, &CWinApp::OnHelp)
END_MESSAGE_MAP()


// CG4mfcApp construction

CG4mfcApp::CG4mfcApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}



// The one and only CG4mfcApp object

CG4mfcApp theApp;


// CG4mfcApp initialization

BOOL CG4mfcApp::InitInstance()
{
	// InitCommonControlsEx() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes you want to use
	// in your application.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinAppEx::InitInstance();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	//startNode(pubList1, 0);
	//startNode(pubList2, 0);
	CG4mfcDlg * pdlg = new CG4mfcDlg();
	m_pMainWnd = pdlg;

	if (pdlg)
	{
		pdlg->Create(IDD_G4MFC_DIALOG);
		pdlg->ShowWindow(SW_SHOW);
		return TRUE;
	}
	else
		return FALSE;


}

BOOL CG4mfcApp::OnIdle(LONG lCount) 
{
	((CG4mfcDlg *)m_pMainWnd)->PeekCont();

	CWinApp::OnIdle( lCount );

	return TRUE;
}

int CG4mfcApp::ExitInstance()
{
	if (m_pMainWnd)
		delete m_pMainWnd;

	return CWinApp::ExitInstance();
}