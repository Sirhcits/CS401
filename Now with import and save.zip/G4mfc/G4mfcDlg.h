
// G4mfcDlg.h : header file
//

#pragma once

#include "PDI.h"
#include "afxwin.h"
#include "G4cfgDlg.h"
//#include "LinkedList.h"

// CG4mfcDlg dialog
class CG4mfcDlg : public CDialog
{
// Construction
public:
	CG4mfcDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CG4mfcDlg();

// Dialog Data
	enum { IDD = IDD_G4MFC_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual void PostNcDestroy();


// Implementation
protected:
	HICON m_hIcon;

	CPDIg4	m_g4;
	ePDIoriUnits m_ePNOOriUnits;

	G4cfgDlg * m_pCfgDlg;
	//G4cfgDlg * m_offline;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	DECLARE_MESSAGE_MAP()

    INT m_nTextSize;
	INT m_nTextLimit;

	CFont m_font;

public:
    VOID    AddMsg		( CString & );
	VOID	AddMsg2		( CString & );
	VOID	AddResultMsg ( LPCTSTR );

	CString m_SrcCalFilePath;
	struct Node *pubList1;
	struct Node *pubList2;
	CString m_import1;
	CString m_import2;
	CString m_text;
	CString m_filename1;
	CString m_filename2;
	CString m_name;
	afx_msg void OnBnClickedButton1();	//Browse for Source Cal File
	afx_msg void OnBnClickedButton13();
	afx_msg void OnBnClickedButton25();
	afx_msg void OnBnClickedButton26();
	afx_msg void OnBnClickedButton10();
	afx_msg void OnBnClickedCheck1();	// ConnectG4( )
	// current connect button state
	BOOL m_bConnected;
	afx_msg void OnBnClickedButton2();	// WhoAmIG4Sys( )
	INT_PTR m_nMaxHubCount;
	INT_PTR m_nSystemID;
	CEdit m_edtOutput;
	CEdit m_edtOutput2;
	int m_nPNOPosUnits;
	afx_msg void OnBnClickedButton3();	// GetPNOPosUnits( )
	afx_msg void OnBnClickedButton4();	// SetPNOPosUnits( )
	afx_msg void OnBnClickedButton5();	// ResetPNOPosUnits
	void InitializeDisplayedSettings(void);
	afx_msg void OnBnClickedButton6();	// GetPNOOriUnits
	int m_nPNOOriUnits;
	afx_msg void OnBnClickedButton7();	// SetPNOOriUnits( )
	afx_msg void OnBnClickedButton8();	// ResetPNOOriUnits( )
	afx_msg void OnBnClickedButton9();	// other settings dialog
	BOOL m_bCmdUnitsAlso;
	//afx_msg void OnBnClickedButton10();	// ReadSinglePnoBufG4( )
	void ParseG4NativeFrame( PBYTE pBuf, DWORD dwSize );
	void PeekCont();
	afx_msg void OnBnClickedCheck3();	// StartContPnoG4( ), StopContPno( )
	CButton m_btnCont;
	BOOL m_bCont;
	afx_msg LRESULT	OnDataStarted	( WPARAM wP, LPARAM lP );
	afx_msg LRESULT	OnDataStopped	( WPARAM wP, LPARAM lP );
	afx_msg LRESULT	OnDataInfo		( WPARAM wP, LPARAM lP );
	UINT m_nLastHostFrameCount;
	afx_msg void OnBnClickedRadio1();
	afx_msg void OnBnClickedRadio2();
	afx_msg void OnBnClickedRadio3();
	afx_msg void OnBnClickedRadio4();
	afx_msg void OnBnClickedRadio5();
	afx_msg void OnBnClickedRadio6();
	afx_msg void OnBnClickedRadio7();
	afx_msg void OnBnClickedCheck2();
	afx_msg void OnBnClickedButton11();
	afx_msg void OnBnClickedButton14();
	CString m_csStationMap;
	int m_nActiveHubCount;
	afx_msg void OnBnClickedButton15();
	CListBox m_listboxActiveHubIDs;
	INT m_nHubIDs[G4_MAX_HUB_COUNT];
	void FillHubIDList();


	CComboBox m_comboSysStationMap;
	UINT64 m_stamap[G4_STAMAP_BLOCK_COUNT];
	afx_msg void OnBnClickedButton16();
	void FillStaMapCombo();

	CString m_csHubStationMap;
	afx_msg void OnBnClickedButton17();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	int sda;
	afx_msg void OnEnChangeEdit2();
	afx_msg void OnEnChangeEdit3();
	afx_msg void OnEnChangeEdit7();
	afx_msg void OnEnChangeEdit5();
	afx_msg void OnEnChangeEdit4();
	afx_msg void OnEnChangeEdit6();
	afx_msg void OnEnChangeEdit10();
	afx_msg void OnLbnSelchangeList2();
	afx_msg void OnEnChangeEdit8();
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnEnChangeEdit1();
	afx_msg void OnEnChangeEdit17();
	afx_msg void OnEnChangeEdit13();
	afx_msg void OnBnClickedButton24();
	//afx_msg void OnBnClickedButton13();
	//afx_msg void OnBnClickedButton25();
	afx_msg void OnLbnSelchangeList1();

	afx_msg void OnEnChangeEdit15();
};
