
// G4mfcDlg.cpp : implementation file
//
// blargle to convert LL to array

#include "stdafx.h"
#include "G4mfc.h"
#include "G4mfcDlg.h"
#include "LinkedList.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <conio.h>

using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

double *stationaryDouble;
double *usageDouble;

// CG4mfcDlg dialog

#define BUFFER_SIZE 0x1AF280   // 15 seconds of 1 hub, 3 sensors at 120 hz = 15*124*120
BYTE	g_pMotionBuf[BUFFER_SIZE]; 
bool stationary = true;
struct Node *list1 = new Node;
struct Node *list2 = new Node;


CG4mfcDlg::CG4mfcDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CG4mfcDlg::IDD, pParent)
	, m_pCfgDlg(0)
	//, m_offline(0)
	, m_SrcCalFilePath(_T("C:\\\Program Files (x86)\\\Polhemus\\\G4\\\G4 Files\\\default.g4c"))
	, m_import1(_T("C:\\\Program Files (x86)"))
	, m_filename1(_T(""))
	, m_filename2(_T(""))
	, m_name(_T(""))
	, pubList1(NULL)
	, pubList2(NULL)
	, m_import2(_T("C:\\\Program Files (x86)"))
	, m_text(_T("Stationary"))
	, m_bConnected(FALSE)
	, m_nMaxHubCount(0)
	, m_nSystemID(0)
	, m_nTextSize(0)
	, m_nTextLimit(0x5000)
	, m_nPNOPosUnits(0)
	, m_nPNOOriUnits(0)
	, m_bCmdUnitsAlso(TRUE)
	, m_bCont(FALSE)
	, m_nLastHostFrameCount(0)
	, m_ePNOOriUnits((ePDIoriUnits)0)
	, m_csStationMap(_T(""))
	, m_nActiveHubCount(0)
	, m_csHubStationMap(_T(""))
	, sda(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_g4.Trace(TRUE, 9);
	m_g4.SetPnoBuffer( g_pMotionBuf, BUFFER_SIZE );

	m_pCfgDlg = new G4cfgDlg( this, &m_g4 );
	m_pCfgDlg->Create(IDD_G4MFC_CONFIG, this );

	memset( &m_nHubIDs[0], 0, sizeof(INT)*G4_MAX_HUB_COUNT);
	memset( &m_stamap[0], 0, sizeof(UINT64)*G4_STAMAP_BLOCK_COUNT);

}

CG4mfcDlg::~CG4mfcDlg()
{
	if (m_pCfgDlg)
	{
		m_pCfgDlg->DestroyWindow();
		delete m_pCfgDlg;
	}
}

void CG4mfcDlg::DoDataExchange(CDataExchange* pDX)
{
	
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_SrcCalFilePath);
	DDX_Check(pDX, IDC_CHECK1, m_bConnected);
	DDX_Text(pDX, IDC_EDIT3, m_filename1);
	DDX_Text(pDX, IDC_EDIT2, m_filename2);
	DDX_Text(pDX, IDC_EDIT15, m_name);
	DDX_Control(pDX, IDC_EDIT4, m_edtOutput);
	DDX_Control(pDX, IDC_EDIT13, m_edtOutput2);
	DDX_Radio(pDX, IDC_RADIO3, m_nPNOPosUnits);
	DDX_Radio(pDX, IDC_RADIO5, m_nPNOOriUnits);
	//DDX_Check(pDX, IDC_CHECK2, m_bCmdUnitsAlso);
	DDX_Control(pDX, IDC_CHECK3, m_btnCont);
	DDX_Check(pDX, IDC_CHECK3, m_bCont);
	DDX_Text(pDX, IDC_EDIT5, m_nLastHostFrameCount);
	//DDX_Text(pDX, IDC_EDIT7, m_csStationMap);
	//DDX_Text(pDX, IDC_EDIT6, m_nActiveHubCount);
	DDV_MinMaxInt(pDX, m_nActiveHubCount, 0, 256);
	//DDX_Control(pDX, IDC_LIST2, m_listboxActiveHubIDs);
	//DDX_Control(pDX, IDC_COMBO1, m_comboSysStationMap);
	//DDX_Text(pDX, IDC_EDIT8, m_csHubStationMap);
	//DDX_Text(pDX, IDC_EDIT17, m_SrcCalFilePath);
	DDX_Text(pDX, IDC_EDIT10, m_text);
}

void CG4mfcDlg::PostNcDestroy() 
{
	delete this;	
}

BEGIN_MESSAGE_MAP(CG4mfcDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CG4mfcDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON13, &CG4mfcDlg::OnBnClickedButton13)
	ON_BN_CLICKED(IDC_BUTTON25, &CG4mfcDlg::OnBnClickedButton25)
	ON_BN_CLICKED(IDC_BUTTON26, &CG4mfcDlg::OnBnClickedButton26)
	ON_BN_CLICKED(IDC_CHECK1, &CG4mfcDlg::OnBnClickedCheck1)
	ON_BN_CLICKED(IDC_BUTTON2, &CG4mfcDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CG4mfcDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CG4mfcDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &CG4mfcDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &CG4mfcDlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON7, &CG4mfcDlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON8, &CG4mfcDlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON9, &CG4mfcDlg::OnBnClickedButton9)
	ON_BN_CLICKED(IDC_BUTTON10, &CG4mfcDlg::OnBnClickedButton10)
	ON_BN_CLICKED(IDC_CHECK3, &CG4mfcDlg::OnBnClickedCheck3)
	ON_MESSAGE(WM_PI_DATA_STARTED, OnDataStarted )
	ON_MESSAGE(WM_PI_DATA_STOPPED, OnDataStopped )
	ON_MESSAGE(WM_PI_DATA_INFO, OnDataInfo )
	ON_BN_CLICKED(IDC_RADIO1, &CG4mfcDlg::OnBnClickedRadio1)
	ON_BN_CLICKED(IDC_RADIO2, &CG4mfcDlg::OnBnClickedRadio2)
	ON_BN_CLICKED(IDC_RADIO3, &CG4mfcDlg::OnBnClickedRadio3)
	ON_BN_CLICKED(IDC_RADIO4, &CG4mfcDlg::OnBnClickedRadio4)
	ON_BN_CLICKED(IDC_RADIO5, &CG4mfcDlg::OnBnClickedRadio5)
	ON_BN_CLICKED(IDC_RADIO6, &CG4mfcDlg::OnBnClickedRadio6)
	ON_BN_CLICKED(IDC_RADIO7, &CG4mfcDlg::OnBnClickedRadio7)
	//ON_BN_CLICKED(IDC_CHECK2, &CG4mfcDlg::OnBnClickedCheck2)
	ON_BN_CLICKED(IDC_BUTTON11, &CG4mfcDlg::OnBnClickedButton11)
	ON_BN_CLICKED(IDC_BUTTON14, &CG4mfcDlg::OnBnClickedButton14)
	ON_BN_CLICKED(IDC_BUTTON15, &CG4mfcDlg::OnBnClickedButton15)
	ON_BN_CLICKED(IDC_BUTTON16, &CG4mfcDlg::OnBnClickedButton16)
	ON_BN_CLICKED(IDC_BUTTON17, &CG4mfcDlg::OnBnClickedButton17)
	ON_WM_SIZE()
	ON_EN_CHANGE(IDC_EDIT2, &CG4mfcDlg::OnEnChangeEdit2)
	ON_EN_CHANGE(IDC_EDIT3, &CG4mfcDlg::OnEnChangeEdit3)
	//ON_EN_CHANGE(IDC_EDIT7, &CG4mfcDlg::OnEnChangeEdit7)
	ON_EN_CHANGE(IDC_EDIT5, &CG4mfcDlg::OnEnChangeEdit5)
	ON_EN_CHANGE(IDC_EDIT4, &CG4mfcDlg::OnEnChangeEdit4)

//	ON_EN_CHANGE(IDC_EDIT6, &CG4mfcDlg::OnEnChangeEdit6)
	ON_EN_CHANGE(IDC_EDIT10, &CG4mfcDlg::OnEnChangeEdit10)
	//ON_LBN_SELCHANGE(IDC_LIST2, &CG4mfcDlg::OnLbnSelchangeList2)
	//ON_EN_CHANGE(IDC_EDIT8, &CG4mfcDlg::OnEnChangeEdit8)
	//ON_CBN_SELCHANGE(IDC_COMBO1, &CG4mfcDlg::OnCbnSelchangeCombo1)
	ON_EN_CHANGE(IDC_EDIT1, &CG4mfcDlg::OnEnChangeEdit1)
	//ON_EN_CHANGE(IDC_EDIT17, &CG4mfcDlg::OnEnChangeEdit17)
	ON_EN_CHANGE(IDC_EDIT13, &CG4mfcDlg::OnEnChangeEdit13)
	ON_BN_CLICKED(IDC_BUTTON24, &CG4mfcDlg::OnBnClickedButton24)

	//ON_LBN_SELCHANGE(IDC_LIST1, &CG4mfcDlg::OnLbnSelchangeList1)
	
	ON_EN_CHANGE(IDC_EDIT15, &CG4mfcDlg::OnEnChangeEdit15)
END_MESSAGE_MAP()


// CG4mfcDlg message handlers

BOOL CG4mfcDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_font.CreateStockObject(ANSI_FIXED_FONT); //default
	m_edtOutput.SetFont(&m_font);
	m_edtOutput2.SetFont(&m_font);

	FillHubIDList();
	FillStaMapCombo();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CG4mfcDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CG4mfcDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CG4mfcDlg::OnClose() 
{
	DestroyWindow();
}

void CG4mfcDlg::OnBnClickedButton1()	//Browse for Source Cal File
{
	UpdateData();
	CFileDialog fdlg( TRUE,      //BOOL bOpenFileDialog, 
					  _T("g4c"),       //LPCTSTR lpszDefExt = NULL, 
					  m_SrcCalFilePath, //LPCTSTR lpszFileName = NULL, 
					  OFN_ENABLESIZING|OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST, //DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, 
					  CString("G4C Files (*.grc)|*.g4c|All Files (*.*)|*.*||"), //LPCTSTR lpszFilter = NULL, 
					  this ); //  CWnd* pParentWnd = NULL );
					  
	if (IDOK == fdlg.DoModal())
	{
		m_SrcCalFilePath = fdlg.GetPathName();
		UpdateData(FALSE);
	}



}

void CG4mfcDlg::OnBnClickedCheck1()	// ConnectG4( )  Toggle Connection
{
//	UpdateData();
	if (!m_bConnected)
	{
		if (m_g4.ConnectG4( m_SrcCalFilePath ))
		{
			m_bConnected = TRUE;
			InitializeDisplayedSettings();
		}
		AddResultMsg( _T("ConnectG4"));
	}
	else
	{
		m_g4.Disconnect();
		AddResultMsg(_T("Disconnect"));
		m_bConnected = FALSE;
	}
	UpdateData(FALSE);
}


VOID CG4mfcDlg::AddMsg2( CString & csMsg){
	m_nTextSize += csMsg.GetLength();

	INT nCount = m_edtOutput2.GetLineCount();
	INT nLastLineIndex = m_edtOutput2.LineIndex(nCount-1);

	if(m_nTextSize >= m_nTextLimit){
		m_edtOutput2.SetSel(0, m_edtOutput2.LineIndex(nCount/2), TRUE);
		m_edtOutput2.ReplaceSel(_T("\0"));

		nCount = m_edtOutput2.GetLineCount();
		nLastLineIndex = m_edtOutput2.LineIndex(nCount-1);
		m_nTextSize = nLastLineIndex;
		//TRACE("Chopped: textsize=%x, linecount=%d, llindex=%d\n", m_nTextSize,nCount,nLastLineIndex);
	}

	// position cursor to end. 
	m_edtOutput2.SetSel(nLastLineIndex, nLastLineIndex, TRUE);
	
	m_edtOutput2.ReplaceSel( csMsg ); 
	nCount = m_edtOutput2.GetLineCount();
	nLastLineIndex = m_edtOutput2.LineIndex(nCount-1);

	// position cursor at end again, and scroll
	m_edtOutput2.SetSel(nLastLineIndex, nLastLineIndex);

	m_edtOutput2.SetModify(FALSE);
	
}

VOID CG4mfcDlg::AddMsg( CString & csMsg )
{
	m_nTextSize += csMsg.GetLength();

	INT		nCount = m_edtOutput.GetLineCount();
	INT		nLastLineIndex = m_edtOutput.LineIndex(nCount-1);

	if (m_nTextSize >= m_nTextLimit)
	{
		//TRACE("Text Limit exceeded, textsize=%x, linecount=%d, llindex=%d\n", m_nTextSize,nCount,nLastLineIndex);
		// chop it in half by removing the first 50%
		m_edtOutput.SetSel(0, m_edtOutput.LineIndex(nCount/2), TRUE);
		m_edtOutput.ReplaceSel(_T("\0"));

		nCount = m_edtOutput.GetLineCount();
		nLastLineIndex = m_edtOutput.LineIndex(nCount-1);
		m_nTextSize = nLastLineIndex;
		//TRACE("Chopped: textsize=%x, linecount=%d, llindex=%d\n", m_nTextSize,nCount,nLastLineIndex);
	}

	// position cursor to end. 
	m_edtOutput.SetSel(nLastLineIndex, nLastLineIndex, TRUE);

	m_edtOutput.ReplaceSel( csMsg ); 
	nCount = m_edtOutput.GetLineCount();
	nLastLineIndex = m_edtOutput.LineIndex(nCount-1);

	// position cursor at end again, and scroll
	m_edtOutput.SetSel(nLastLineIndex, nLastLineIndex);

	m_edtOutput.SetModify(FALSE);
}

VOID
CG4mfcDlg::AddResultMsg( LPCTSTR szCmd )
{
	CString msg;
	msg.Format(_T("%s result: %s\r\n"), szCmd, m_g4.GetLastResultStr() );
	AddMsg( msg );
	AddMsg2(msg);
}



void CG4mfcDlg::OnBnClickedButton3()	// GetPNOPosUnits( )
{
	ePDIposUnits ePU;

	UpdateData();

	if (m_g4.GetPNOPosUnits( ePU, m_bCmdUnitsAlso ))
	{
		m_nPNOPosUnits = (INT)ePU;

		if (m_bCmdUnitsAlso)
		{
			m_pCfgDlg->m_nCmdPosUnits = m_nPNOPosUnits;
			m_pCfgDlg->UpdateData(FALSE);
		}

		UpdateData(FALSE);

	}
	AddResultMsg(_T("GetPNOPosUnits"));
}

void CG4mfcDlg::OnBnClickedButton4()	// SetPNOPosUnits( )
{
	UpdateData();

	if (m_g4.SetPNOPosUnits((ePDIposUnits) m_nPNOPosUnits, m_bCmdUnitsAlso))
	{
		if (m_bCmdUnitsAlso)
		{
			m_pCfgDlg->m_nCmdPosUnits = m_nPNOPosUnits;
			m_pCfgDlg->UpdateData(FALSE);
		}
	}
	AddResultMsg(_T("SetPNOPosUnits"));
}

void CG4mfcDlg::OnBnClickedButton5()	// ResetPNOPosUnits
{
	m_g4.ResetPNOPosUnits();
	AddResultMsg(_T("ResetPNOPosUnits"));

	OnBnClickedButton3();	// Read it again to update screen
}

void CG4mfcDlg::InitializeDisplayedSettings(void)
{
	OnBnClickedButton3();	// Initialize PNO Pos units
	OnBnClickedButton6();	// PNO Ori Units

	//m_pCfgDlg->InitializeDisplayedSettings(); 
}

void CG4mfcDlg::OnBnClickedButton6()	// GetPNOOriUnits
{
	UpdateData();

	ePDIoriUnits eOU;
	if (m_g4.GetPNOOriUnits( eOU, m_bCmdUnitsAlso ))
	{
		m_nPNOOriUnits = (INT)eOU;
		m_ePNOOriUnits = eOU;

		if (m_bCmdUnitsAlso)
		{
			m_pCfgDlg->m_nCmdOriUnits = m_nPNOOriUnits;
			m_pCfgDlg->EnableDlgItems();
			m_pCfgDlg->UpdateData(FALSE);
		}

		UpdateData(FALSE);
	}
	AddResultMsg(_T("GetPNOOriUnits"));
}

void CG4mfcDlg::OnBnClickedButton7()	// SetPNOOriUnits( )
{
	UpdateData();

	if (m_g4.SetPNOOriUnits((ePDIoriUnits) m_nPNOOriUnits))
	{
		m_ePNOOriUnits = (ePDIoriUnits) m_nPNOOriUnits;

		if (m_bCmdUnitsAlso)
		{
			m_pCfgDlg->m_nCmdOriUnits = m_nPNOOriUnits;
			m_pCfgDlg->UpdateData(FALSE);
		}
	}
	AddResultMsg(_T("SetPNOOriUnits"));
}

void CG4mfcDlg::OnBnClickedButton8()	// ResetPNOOriUnits( )
{
	m_g4.ResetPNOOriUnits();
	AddResultMsg(_T("ResetPNOOriUnits"));

	OnBnClickedButton6();	// Read it again to update screen
}

void CG4mfcDlg::OnBnClickedButton9()	// GetFrameOfRef( PDI7vec & )
{
	m_pCfgDlg->ShowWindow(SW_SHOW);
}

void CG4mfcDlg::OnBnClickedButton10()	// ReadSinglePnoBufG4( )
{/*
	PBYTE pBuf;
	DWORD dwSize;
	UpdateData();

	if (!(m_g4.ReadSinglePnoBufG4( pBuf, dwSize)))
	{
		AddResultMsg( _T("ReadSinglePnoBufG4"));
	}
	else
	{
		ParseG4NativeFrame( pBuf, dwSize );
	}*/
	//SaveUserNameandData

	int counter = 0;

	struct Node *temp = new Node;

	temp = list1->next;
	ofstream outf1(m_name + "_Stationary_Data.txt");

	while(temp){
		outf1 << temp->data << "  ";
		temp = temp->next;
		counter++;
		if(counter == 6){
			outf1 << endl;
			counter = 0;
		}
	}

	counter = 0;
	temp = list2->next;
	ofstream outf(m_name + "_Usage_Data.txt");
	
	while(temp){
		outf << temp->data << "  ";
		temp = temp->next;
		counter++;
		if(counter == 6){
			outf << endl;
			counter = 0;
		}
	}
}
//typedef struct {				// per sensor P&O data
//	UINT32 nSnsID;
//	float pos[3];
//	float ori[4];
//}*LPG4_SENSORDATA,G4_SENSORDATA;//36 bytes
//
//typedef struct {				// per hub P&O data
//	UINT32 nHubID;
//	UINT32 nFrameCount;
//	UINT32 dwSensorMap;	
//	UINT32 dwDigIO;
//	G4_SENSORDATA sd[G4_MAX_SENSORS_PER_HUB];
//}*LPG4_HUBDATA,G4_HUBDATA;				

void CG4mfcDlg::ParseG4NativeFrame( PBYTE pBuf, DWORD dwSize )
{
//	struct Node *list1 = new Node;
//	struct Node *list2 = new Node;
	struct Node *temp = new Node;
	
	double *array1;
	double *array2;
	if(list1->next == NULL)
		startNode(list1, 0);
	if(list2->next == NULL)
		startNode(list2, 0);

	if ((!pBuf) || (!dwSize))
	{}
	else
	{
		DWORD i= 0;
		LPG4_HUBDATA	pHubFrame;

		while (i < dwSize )
		{
			pHubFrame = (LPG4_HUBDATA)(&pBuf[i]);

			i += sizeof(G4_HUBDATA);

			UINT	nHubID = pHubFrame->nHubID;
			UINT	nFrameNum =  pHubFrame->nFrameCount;
			UINT	nSensorMap = pHubFrame->dwSensorMap;
			UINT	nDigIO = pHubFrame->dwDigIO;

			UINT	nSensMask = 1;

			CString msg;

			for (int j=0; j<G4_MAX_SENSORS_PER_HUB; j++)
			{
				if (((nSensMask << j) & nSensorMap) != 0)
				{
					G4_SENSORDATA * pSD = &(pHubFrame->sd[j]);
					if (m_ePNOOriUnits == E_PDI_ORI_QUATERNION)
					{
						msg.Format(_T("  %3d| % 7.3f % 7.3f % 7.3f| % 8.4f % 8.4f % 8.4f % 8.4f\r\n"),
								pSD->nSnsID + 1,
								pSD->pos[0], pSD->pos[1], pSD->pos[2],
								pSD->ori[0], pSD->ori[1], pSD->ori[2], pSD->ori[3] );
					}
					else
					{
						msg.Format(_T("  %3d| % 7.3f % 7.3f % 7.3f| % 8.3f % 8.3f % 8.3f\r\n"),
								pSD->nSnsID + 1,
								pSD->pos[0], pSD->pos[1], pSD->pos[2],
								pSD->ori[0], pSD->ori[1], pSD->ori[2] );


						//if true, save the data on pubList1 the stationary values
						if(stationary){
							addNode(list1, pSD->pos[0]);
							addNode(list1, pSD->pos[1]);
							addNode(list1, pSD->pos[2]);
							addNode(list1, pSD->ori[0]);
							addNode(list1, pSD->ori[1]);
							addNode(list1, pSD->ori[2]);
						}
						//if false, save the data on list2, the values when someone's using it :D
						else{
							addNode(list2, pSD->pos[0]);
							addNode(list2, pSD->pos[1]);
							addNode(list2, pSD->pos[2]);
							addNode(list2, pSD->ori[0]);
							addNode(list2, pSD->ori[1]);
							addNode(list2, pSD->ori[2]);
						}

					}
					/*
					outputFile(pubList1, "list1.txt");
					outputFile(pubList2, "list2.txt");
					*/
					//Go here if you want to save the linked list to an array search tag [blargle]
					//pubList1 = list1->next;
					//pubList2 = list2->next;
					int size1 = listSize(pubList1);
					int size2 = listSize(pubList2);

					array1 = new double[size1];
					array2 = new double[size2];
					
					temp = pubList1;
					for(int i = 1; i < size1; i++){
						array1[i] = temp->data;
						temp = temp->next;
					}
					temp=pubList2;
					for(int i = 1; i < size2; i++){
						array2[i] = temp->data;
						temp = temp->next;
					}

					if(stationary)
						AddMsg(msg);
					else
						AddMsg2(msg);
				}
			}

		} // end while dwsize
	}
}

void CG4mfcDlg::PeekCont()
{
	if (!m_bCont)
	{
		return;
	}

	PBYTE pBuf;
	DWORD dwSize;
	DWORD dwFC;

	if (!(m_g4.LastHostFrameCount( dwFC )))
	{
		AddResultMsg(_T("LastHostFrameCount"));
	}
	else if (dwFC == m_nLastHostFrameCount)
	{
		// no new frames since last peek
	}
	else if (!(m_g4.LastPnoPtr( pBuf, dwSize )))
	{
		AddResultMsg(_T("LastPnoPtr"));
	}
	else 
	{
		m_nLastHostFrameCount = dwFC;
		ParseG4NativeFrame( pBuf, dwSize );
		//CString msg;
		//msg.Format(_T("m_nLastHostFrameCount %d\r\n"), m_nLastHostFrameCount );
		//AddMsg(msg);
		UpdateData(FALSE);
	}
}


/*struct Node *newHead;
struct Node *list1 = new Node;
struct Node *list2 = new Node;
//first value of each node is zero just so it's easier for me
double garbage = 0;
struct Node *temp = new Node;*/




void CG4mfcDlg::OnBnClickedCheck3()	// StartContPnoG4( ), StopContPno( )
{
	BOOL bRes = FALSE;
	if (!m_bCont)
	{
		bRes = m_g4.StartContPnoG4( m_hWnd );
		//AddResultMsg(_T("StartContPnoG4") );
	}
	else
	{
		bRes = m_g4.StopContPno();
		//AddResultMsg(_T("StopContPno"));

		stationary = (!stationary);

		if(stationary)
			m_text = "Stationary";
		else
			m_text = "In Use";

		//UpdateData();
	}

	if (bRes)
	{
		m_btnCont.EnableWindow(FALSE);
	}
	else
	{
		UpdateData(FALSE);
	}

}

// wP = dongle id
LRESULT CG4mfcDlg::OnDataStarted( WPARAM wP, LPARAM lP )
{
    CString     msg;
	msg.Format(_T("WM_PI_DATA_STARTED, SysID %d \r\n"), wP );
	//AddMsg(msg);
	//AddMsg2(msg);


	m_bCont = TRUE;
	m_nLastHostFrameCount = 0;
	m_btnCont.SetWindowText( _T("Stop Recording"));
	m_btnCont.EnableWindow(TRUE);
	UpdateData(FALSE);

    return 0;
}

LRESULT CG4mfcDlg::OnDataStopped( WPARAM wP, LPARAM lP )
{
    CString     msg;
	msg.Format(_T("WM_PI_DATA_STOPPED, SysID %d \r\n"), wP );
	//AddMsg(msg);
	//AddMsg2(msg);

	m_bCont = FALSE;
	m_btnCont.SetWindowText( _T("Start Recording"));
	m_btnCont.EnableWindow(TRUE);
	UpdateData(FALSE);
    return 0;
}
LRESULT	
CG4mfcDlg::OnDataInfo( WPARAM wP, LPARAM lP )
{
    CString     msg;
	msg.Format(_T("WM_PI_DATA_INFO received: %s\r\n"), 
		m_g4.ResultStr( (ePiErrCode)wP, (ePiDevError)lP ));
	//AddMsg(msg);
	//AddMsg2(msg);

    return 0;
}

//INCH
void CG4mfcDlg::OnBnClickedRadio1()
{
	UpdateData();
}

//FOOT
void CG4mfcDlg::OnBnClickedRadio2()
{
	UpdateData();
}


//CM
void CG4mfcDlg::OnBnClickedRadio3()
{
	UpdateData();
}


//M
void CG4mfcDlg::OnBnClickedRadio4()
{
	UpdateData();
}

//ANGLES

//Degree
void CG4mfcDlg::OnBnClickedRadio5()
{
	UpdateData();
}

//Radian
void CG4mfcDlg::OnBnClickedRadio6()
{
	UpdateData();
}

//Quarternion
void CG4mfcDlg::OnBnClickedRadio7()
{
	UpdateData();
}

//Check box CMD also?
/*void CG4mfcDlg::OnBnClickedCheck2()
{
	UpdateData();
}*/

void CG4mfcDlg::OnBnClickedButton11()
{
	m_edtOutput.SetWindowText(_T(""));
}



void CG4mfcDlg::OnBnClickedButton15()
{
	if (!(m_g4.GetActiveHubs( this->m_nActiveHubCount, m_nHubIDs )))
	{}
	else
	{
		FillHubIDList();
	}
	AddResultMsg( _T("GetActiveHubs"));
	UpdateData(FALSE);
}

void CG4mfcDlg::FillHubIDList()
{
	m_listboxActiveHubIDs.ResetContent();

	for (int i=0; i<m_nActiveHubCount; i++)
	{
		CString csID;
		csID.Format(_T("%d"), m_nHubIDs[i] );
		int item = m_listboxActiveHubIDs.AddString( csID );
		m_listboxActiveHubIDs.SetItemData( item, m_nHubIDs[i] );
	}
	if (m_nActiveHubCount)
		m_listboxActiveHubIDs.SetCurSel(0);
}
void CG4mfcDlg::OnBnClickedButton16()
{
	if (!(m_g4.GetSysSensorMap( m_stamap )))
	{}
	else
	{
		FillStaMapCombo();
	}
	AddResultMsg( _T("GetSysSensorMap"));
	UpdateData(FALSE);
}

void CG4mfcDlg::FillStaMapCombo()
{
	m_comboSysStationMap.ResetContent();
	
	for (int i=0; i<G4_STAMAP_BLOCK_COUNT; i++)
	{
		CString csMap;
		for (int j=(sizeof(UINT64)*8)-1; j>=0; j--)
		{
			csMap += (m_stamap[i] & (1i64<<j)) ? CString('1') : CString('0');
			if ((j%4) == 0)
				csMap += CString(' ');
		}
		m_comboSysStationMap.AddString(csMap);
		//AddMsg( csMap );
	}
	m_comboSysStationMap.SetCurSel(0);
}
void CG4mfcDlg::OnBnClickedButton17()
{
	int item = m_listboxActiveHubIDs.GetCurSel();
	if (item == LB_ERR)
	{
		::AfxMessageBox(_T("Select an Active Hub ID first.."), MB_OK );
	}
	else
	{
		int hubID = (int)m_listboxActiveHubIDs.GetItemData(item);
		DWORD dwMap;

		if (!(m_g4.GetHubSensorMap( hubID, dwMap )))
		{}
		else
		{
			this->m_csHubStationMap.Format(_T("0x%02x"), dwMap );
		}
	}
	UpdateData(FALSE);
}

#define DLG_MARGIN 10
void CG4mfcDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

    if (!(::IsWindow(m_edtOutput)))
    {
        return;
    }

	RECT  cr, wr, ocr, owr;

	GetWindowRect( &wr );
	GetClientRect( &cr );
	m_edtOutput.GetWindowRect( &owr );
	m_edtOutput.GetClientRect( &ocr );	


    // Rsp Edit
    ocr.right = cr.right - (2*DLG_MARGIN);
    ocr.bottom = cr.bottom - (owr.top-wr.top) + DLG_MARGIN;
	TRACE("m_edtOutput pos: ( %d, %d )  , size: (%d, %d )\n", ocr.left, ocr.top, ocr.right, ocr.bottom );
    m_edtOutput.SetWindowPos( NULL, ocr.left, ocr.top, ocr.right, ocr.bottom, SWP_NOMOVE );
}



void CG4mfcDlg::OnEnChangeEdit2()
{
	UpdateData();
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}

void CG4mfcDlg::OnEnChangeEdit3()
{
	UpdateData();
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}

/*
void CG4mfcDlg::OnEnChangeEdit7()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here

}*/


void CG4mfcDlg::OnEnChangeEdit5()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}


void CG4mfcDlg::OnEnChangeEdit4()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}

/*
void CG4mfcDlg::OnEnChangeEdit6()
{
	int x = 10;
	
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}*/


void CG4mfcDlg::OnEnChangeEdit10()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}

/*
void CG4mfcDlg::OnLbnSelchangeList2()
{
	// TODO: Add your control notification handler code here
}*/

/*
void CG4mfcDlg::OnEnChangeEdit8()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}*/

/*
void CG4mfcDlg::OnCbnSelchangeCombo1()
{
	// TODO: Add your control notification handler code here
}*/


void CG4mfcDlg::OnEnChangeEdit1()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}

/*
void CG4mfcDlg::OnEnChangeEdit17()
{
	m_SrcCalFilePath.SetReadOnly();
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}*/


void CG4mfcDlg::OnEnChangeEdit13()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}


void CG4mfcDlg::OnBnClickedButton24()
{
	m_edtOutput2.SetWindowText(_T(""));
	// TODO: Add your control notification handler code here
}

double convertToDouble(std::string const& s){
	std::istringstream i(s);
	double x;
	i >> x;
	return x;
}
void CG4mfcDlg::OnBnClickedButton13()
{
	CFileDialog im1(TRUE, NULL, NULL, OFN_ENABLESIZING|OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST, "Text Files (*.txt)|*.txt||");

	int iRet = im1.DoModal();

	m_import1 = im1.GetPathName();

	ifstream inf (m_import1);

	struct Node *head = new Node;
	struct Node *temp = new Node;

	string starter;
	double testVal;
	inf >> starter;
	testVal = convertToDouble(starter);
	startNode(head, testVal);
	
	while(inf){
		string strIn;
		inf >> strIn;
		testVal = convertToDouble(strIn);
		addNode(head, testVal);
	}
	int size = listSize(head);
	temp = head;
	int counter = 1;
	CString msg;

	double *arrayTest;
	arrayTest = new double[size];

	for(int i = 0; i < size; i++){
		arrayTest[i] = temp->data;
		temp = temp->next;
	}
	for(int i = 0; i < size; i=i+6){	
		msg.Format(_T("  %3d| % 7.3f % 7.3f % 7.3f| % 8.3f % 8.3f % 8.3f\r\n"), counter, arrayTest[i], arrayTest[i+1],arrayTest[i+2],arrayTest[i+3],arrayTest[i+4],arrayTest[i+5]);
		counter++;
		if(counter==4)
			counter = 1;
		AddMsg(msg);
	}
	
}

void CG4mfcDlg::OnBnClickedButton14() // Save file
{
	//int x = listSize(pubList1);
	int counter = 0;

	struct Node *temp = new Node;
	temp = list1->next;
	//m_filename1 = m_filename1 + ".txt";
	ofstream outf(m_filename1+".txt");
	
	while(temp){
		outf << temp->data << "  ";
		temp = temp->next;
		counter++;
		if(counter == 6){
			outf << endl;
			counter = 0;
		}
	}/*
	
	for(int i = 0; i < 10; i++){
		outf << listSize(temp) << endl;
	}*/
}

void CG4mfcDlg::OnBnClickedButton2()	// WhoAmIG4Sys( )
{
	//m_offline->ShowWindow(SW_SHOW);
	/*UpdateData(TRUE);

	LPCTSTR	szWho;

	m_g4.WhoAmIG4Sys( m_nSystemID, m_nMaxHubCount, szWho );
	AddResultMsg( _T("WhoAmIG4Sys"));
	AddMsg( CString(szWho) );

	UpdateData(FALSE);*/

	int counter = 0;

	struct Node *temp = new Node;
	temp = list2->next;
	ofstream outf(m_filename2+".txt");
	
	while(temp){
		outf << temp->data << "  ";
		temp = temp->next;
		counter++;
		if(counter == 6){
			outf << endl;
			counter = 0;
		}
	}

}



void CG4mfcDlg::OnBnClickedButton25()
{
	CFileDialog im2(TRUE, NULL, NULL, OFN_ENABLESIZING|OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST, "Text Files (*.txt)|*.txt||");

	int iRet = im2.DoModal();

	m_import2 = im2.GetPathName();

	ifstream inf (m_import2);

	struct Node *head = new Node;
	struct Node *temp = new Node;

	string starter;
	double testVal;
	inf >> starter;
	testVal = convertToDouble(starter);
	startNode(head, testVal);
	
	while(inf){
		string strIn;
		inf >> strIn;
		testVal = convertToDouble(strIn);
		addNode(head, testVal);
	}
	int size = listSize(head);
	temp = head;
	int counter = 1;
	CString msg;

	double *arrayTest;
	arrayTest = new double[size];

	for(int i = 0; i < size; i++){
		arrayTest[i] = temp->data;
		temp = temp->next;
	}
	for(int i = 0; i < size; i=i+6){	
		msg.Format(_T("  %3d| % 7.3f % 7.3f % 7.3f| % 8.3f % 8.3f % 8.3f\r\n"), counter, arrayTest[i], arrayTest[i+1],arrayTest[i+2],arrayTest[i+3],arrayTest[i+4],arrayTest[i+5]);
		counter++;
		if(counter==4)
			counter = 1;
		AddMsg2(msg);
	}
	
}



void CG4mfcDlg::OnBnClickedButton26()
{
	startNode(list1, 0);
	startNode(list2, 0);

	m_filename1 = "";
	m_filename2 = "";
	m_name = "";

	m_edtOutput.SetWindowText(_T(""));
	m_edtOutput2.SetWindowText(_T(""));
	UpdateData();
}


void CG4mfcDlg::OnEnChangeEdit15()
{
	UpdateData();
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}
