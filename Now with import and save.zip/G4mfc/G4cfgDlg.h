#pragma once
#include "afxwin.h"
#include "PDI.h"


// G4cfgDlg dialog
class CPDIg4;
class CG4mfcDlg;

class G4cfgDlg : public CDialog
{
	DECLARE_DYNAMIC(G4cfgDlg)

public:
	G4cfgDlg(CG4mfcDlg* pParent = NULL, CPDIg4 * pG4=0 );   // standard constructor
	virtual ~G4cfgDlg();

// Dialog Data
	enum { IDD = IDD_G4MFC_CONFIG };

protected:

	CPDIg4 * m_pg4;
	CG4mfcDlg * m_pParent;

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

public:
	float m_fFoRrot_0;
	float m_fFoRrot_1;
	float m_fFoRrot_2;
	float m_fFoRrot_3;
	float m_fFoRtrans_0;
	float m_fFoRtrans_1;
	float m_fFoRtrans_2;
	CEdit m_edtFORrotQ3;
	afx_msg void OnBnClickedButton9();	// GetFrameOfRef( PDI7vec & )
	afx_msg void OnBnClickedButton10();	// SetFrameOfRef( PDI7vec & )
	afx_msg void OnBnClickedButton11();	// ResetFrameOfRef( )
	void EnableDlgItems();
	int m_nCmdPosUnits;
	int m_nCmdOriUnits;
	afx_msg void OnCbnSelchangeCombo1(); // SetCmdPosUnits( )
	afx_msg void OnCbnSelchangeCombo2(); // SetCmdOriUnits( )
	//float m_AttFilterm_fSensitivity;
	//float m_AttFilterm_fLowValue;
	//float m_AttFilterm_fHighValue;
	//float m_AttFilterm_fMaxTransRate;
	//float m_PosFilterm_fSensitivity;
	//float m_PosFilterm_fLowValue;
	//float m_PosFilterm_fHighValue;
	//float m_PosFilterm_fMaxTransRate;
	BOOL m_bFiltersAllHubs;
	int m_nFiltersCmdHub;
	afx_msg void OnBnClickedButton1();	// GetHAttFilter( )
	CPDIfilter m_AttFilter;
	CPDIfilter m_PosFilter;
	afx_msg void OnBnClickedCheck1();	// Filter Cmd All Hubs
	CEdit m_edtFiltersCmdHub;
	afx_msg void OnBnClickedButton2();	// SetHAttFilter( )
	afx_msg void OnBnClickedButton3();	// ResetHAttFilter( )
	afx_msg void OnBnClickedButton12();	// GetHPosFilter( )
	afx_msg void OnBnClickedButton13();	// SetHPosFilter( )
	afx_msg void OnBnClickedButton6();	// ResetHPosFilter( )
	void InitializeDisplayedSettings(void);
	afx_msg void OnBnClickedButton7();	// GetHFilters( )
	afx_msg void OnBnClickedButton8();	// SetHFilters( )
	afx_msg void OnBnClickedButton14(); // ResetHFilters( )
	float m_fPosIncr;
	float m_fOriIncr;
	afx_msg void OnBnClickedButton15();	// GetSIncrement( )
	BOOL m_bSCmdAllHubs;
	int m_nSCmdHub;
	int m_nSCmdSens;
	afx_msg void OnBnClickedButton16();	// SetSIncrement()
	afx_msg void OnBnClickedButton17();	// ResetSIncrement()
	//float m_vBore0;
	//float m_vBore1;
	//float m_vBore2;
	//float m_vBore3;
	CEdit m_edtBore3;
	PDI4vec m_vBore;
	afx_msg void OnBnClickedCheck2();	// Sensor Command All Hubs Checked
	CEdit m_edtSCmdHub;
	CEdit m_edtSCmdSens;
	afx_msg void OnBnClickedButton18();	// GetSBoresight( PDI4vec & )
	afx_msg void OnBnClickedButton19();	// SetSBoresight( PDI4vec & )
	afx_msg void OnBnClickedButton20();	// ResetSBoresight( )
	//float m_vTipOffset0;
	//float m_vTipOffset1;
	//float m_vTipOffset2;
	PDI3vec m_vTipOffset;
	afx_msg void OnBnClickedButton21();	// GetSTipOffset( )
	afx_msg void OnBnClickedButton22();	// SetSTipOffset( )
	afx_msg void OnBnClickedButton23();
};
