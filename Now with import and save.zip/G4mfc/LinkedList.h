#pragma once

#include <iostream>
#include <fstream>
using namespace std;

struct Node{
	struct Node* next;
	double data;
};
//Start a linked list

void startNode(struct Node *head, double val){
	head->data = val;
	head->next = NULL;
}
//adds a node to the linked list
void addNode(struct Node *head, double val){
	Node *newNode = new Node;
	newNode->data = val;
	newNode->next = NULL;

	Node *current = head;
	while(current){
		if(current->next == NULL){
			current->next = newNode;
			return;
		}
		current = current->next;
	}
}

//returns the size of the linked list
int listSize(struct Node *head){
	int x = 0;
	Node *current = head;
	while(current){
		if(current->next == NULL)
			break;

		current = current->next;
		x++;
	}
	return x;
}

//output to a file
void outputFile(struct Node *head, string fileName){
	//saves the file as the filename
	ofstream outf(fileName);
	Node *list = head;
	int counter = 0;
	while(list){
		outf << list->data <<"\t";
		counter++;
		if(counter == 6){
			outf<<endl;
			counter = 0;
		}
	}
}