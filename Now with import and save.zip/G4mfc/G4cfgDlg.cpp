// G4cfgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "G4mfc.h"
#include "G4cfgDlg.h"
#include "G4mfcDlg.h"


// G4cfgDlg dialog

IMPLEMENT_DYNAMIC(G4cfgDlg, CDialog)

G4cfgDlg::G4cfgDlg(CG4mfcDlg* pParent /*=NULL*/, CPDIg4 * pG4)
	: CDialog(G4cfgDlg::IDD, pParent)
	, m_pParent( pParent )
	, m_pg4( pG4 )
	, m_fFoRrot_0(0)
	, m_fFoRrot_1(0)
	, m_fFoRrot_2(0)
	, m_fFoRrot_3(0)
	, m_fFoRtrans_0(0)
	, m_fFoRtrans_1(0)
	, m_fFoRtrans_2(0)
	, m_nCmdPosUnits(0)
	, m_nCmdOriUnits(0)
	//, m_AttFilterm_fSensitivity(0)
	//, m_AttFilterm_fLowValue(0)
	//, m_AttFilterm_fHighValue(0)
	//, m_AttFilterm_fMaxTransRate(0)
	//, m_PosFilterm_fSensitivity(0)
	//, m_PosFilterm_fLowValue(0)
	//, m_PosFilterm_fHighValue(0)
	//, m_PosFilterm_fMaxTransRate(0)
	, m_bFiltersAllHubs(FALSE)
	, m_nFiltersCmdHub(0)
	, m_fPosIncr(0)
	, m_fOriIncr(0)
	, m_bSCmdAllHubs(FALSE)
	, m_nSCmdHub(0)
	, m_nSCmdSens(0)
	//, m_vBore0(0)
	//, m_vBore1(0)
	//, m_vBore2(0)
	//, m_vBore3(0)
	//, m_vTipOffset0(0)
	//, m_vTipOffset1(0)
	//, m_vTipOffset2(0)
{
	memset( m_vBore, 0, sizeof( m_vBore ) );
	memset( m_vTipOffset, 0, sizeof( m_vTipOffset ) );
}

G4cfgDlg::~G4cfgDlg()
{
}

void G4cfgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT5, m_fFoRrot_0);
	DDX_Text(pDX, IDC_EDIT6, m_fFoRrot_1);
	DDX_Text(pDX, IDC_EDIT7, m_fFoRrot_2);
	DDX_Text(pDX, IDC_EDIT8, m_fFoRrot_3);
	DDX_Text(pDX, IDC_EDIT9, m_fFoRtrans_0);
	DDX_Text(pDX, IDC_EDIT10, m_fFoRtrans_1);
	DDX_Text(pDX, IDC_EDIT11, m_fFoRtrans_2);
	DDX_Control(pDX, IDC_EDIT8, m_edtFORrotQ3);
	DDX_CBIndex(pDX, IDC_COMBO1, m_nCmdPosUnits);
	DDX_CBIndex(pDX, IDC_COMBO2, m_nCmdOriUnits);
	DDX_Text(pDX, IDC_EDIT1, m_AttFilter.m_fSensitivity);
	DDX_Text(pDX, IDC_EDIT2, m_AttFilter.m_fLowValue);
	DDX_Text(pDX, IDC_EDIT3, m_AttFilter.m_fHighValue);
	DDX_Text(pDX, IDC_EDIT4, m_AttFilter.m_fMaxTransRate);
	DDX_Text(pDX, IDC_EDIT12, m_PosFilter.m_fSensitivity);
	DDX_Text(pDX, IDC_EDIT13, m_PosFilter.m_fLowValue);
	DDX_Text(pDX, IDC_EDIT14, m_PosFilter.m_fHighValue);
	DDX_Text(pDX, IDC_EDIT15, m_PosFilter.m_fMaxTransRate);
	DDX_Check(pDX, IDC_CHECK1, m_bFiltersAllHubs);
	DDX_Text(pDX, IDC_EDIT16, m_nFiltersCmdHub);
	DDV_MinMaxInt(pDX, m_nFiltersCmdHub, 0, 100);
	DDX_Control(pDX, IDC_EDIT16, m_edtFiltersCmdHub);
	DDX_Text(pDX, IDC_EDIT18, m_fPosIncr);
	DDX_Text(pDX, IDC_EDIT19, m_fOriIncr);
	DDX_Check(pDX, IDC_CHECK2, m_bSCmdAllHubs);
	DDX_Text(pDX, IDC_EDIT20, m_nSCmdHub);
	DDV_MinMaxInt(pDX, m_nSCmdHub, 0, 100);
	DDX_Text(pDX, IDC_EDIT21, m_nSCmdSens);
	DDV_MinMaxInt(pDX, m_nSCmdSens, 0, 2);
	DDX_Text(pDX, IDC_EDIT22, m_vBore[0]);
	DDX_Text(pDX, IDC_EDIT23, m_vBore[1]);
	DDX_Text(pDX, IDC_EDIT24, m_vBore[2]);
	DDX_Text(pDX, IDC_EDIT25, m_vBore[3]);
	DDX_Control(pDX, IDC_EDIT25, m_edtBore3);
	DDX_Control(pDX, IDC_EDIT20, m_edtSCmdHub);
	DDX_Control(pDX, IDC_EDIT21, m_edtSCmdSens);
	DDX_Text(pDX, IDC_EDIT26, m_vTipOffset[0]);
	DDX_Text(pDX, IDC_EDIT27, m_vTipOffset[1]);
	DDX_Text(pDX, IDC_EDIT28, m_vTipOffset[2]);
}


BEGIN_MESSAGE_MAP(G4cfgDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON9, &G4cfgDlg::OnBnClickedButton9)
	ON_BN_CLICKED(IDC_BUTTON10, &G4cfgDlg::OnBnClickedButton10)
	ON_BN_CLICKED(IDC_BUTTON11, &G4cfgDlg::OnBnClickedButton11)
	ON_CBN_SELCHANGE(IDC_COMBO1, &G4cfgDlg::OnCbnSelchangeCombo1)
	ON_CBN_SELCHANGE(IDC_COMBO2, &G4cfgDlg::OnCbnSelchangeCombo2)
	ON_BN_CLICKED(IDC_BUTTON1, &G4cfgDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_CHECK1, &G4cfgDlg::OnBnClickedCheck1)
	ON_BN_CLICKED(IDC_BUTTON2, &G4cfgDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &G4cfgDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON12, &G4cfgDlg::OnBnClickedButton12)
	ON_BN_CLICKED(IDC_BUTTON13, &G4cfgDlg::OnBnClickedButton13)
	ON_BN_CLICKED(IDC_BUTTON6, &G4cfgDlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON7, &G4cfgDlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON8, &G4cfgDlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON14, &G4cfgDlg::OnBnClickedButton14)
	ON_BN_CLICKED(IDC_BUTTON15, &G4cfgDlg::OnBnClickedButton15)
	ON_BN_CLICKED(IDC_BUTTON16, &G4cfgDlg::OnBnClickedButton16)
	ON_BN_CLICKED(IDC_BUTTON17, &G4cfgDlg::OnBnClickedButton17)
	ON_BN_CLICKED(IDC_CHECK2, &G4cfgDlg::OnBnClickedCheck2)
	ON_BN_CLICKED(IDC_BUTTON18, &G4cfgDlg::OnBnClickedButton18)
	ON_BN_CLICKED(IDC_BUTTON19, &G4cfgDlg::OnBnClickedButton19)
	ON_BN_CLICKED(IDC_BUTTON20, &G4cfgDlg::OnBnClickedButton20)
	ON_BN_CLICKED(IDC_BUTTON21, &G4cfgDlg::OnBnClickedButton21)
	ON_BN_CLICKED(IDC_BUTTON22, &G4cfgDlg::OnBnClickedButton22)
	ON_BN_CLICKED(IDC_BUTTON23, &G4cfgDlg::OnBnClickedButton23)
END_MESSAGE_MAP()


// G4cfgDlg message handlers

void G4cfgDlg::OnBnClickedButton9() 	// GetFrameOfRef( PDI7vec & )
{
	PDI7vec v;

	if (m_pg4->GetFrameOfRef( v ))
	{
		m_fFoRtrans_0 = v[0];
		m_fFoRtrans_1 = v[1];
		m_fFoRtrans_2 = v[2];
		m_fFoRrot_0   = v[3];
		m_fFoRrot_1   = v[4];
		m_fFoRrot_2   = v[5];
		m_fFoRrot_3   = v[6];

		UpdateData(FALSE);	
	}

	m_pParent->AddResultMsg(_T("GetFrameOfRef( PDI7vec & )"));
}

void G4cfgDlg::OnBnClickedButton10()	// SetFrameOfRef( PDI7vec & )
{
	PDI7vec v;

	UpdateData();

	v[0] = m_fFoRtrans_0;
	v[1] = m_fFoRtrans_1;
	v[2] = m_fFoRtrans_2;
	v[3] = m_fFoRrot_0  ;
	v[4] = m_fFoRrot_1  ;
	v[5] = m_fFoRrot_2  ;
	v[6] = m_fFoRrot_3  ;

	m_pg4->SetFrameOfRef( v );
	m_pParent->AddResultMsg( _T("SetFrameOfRef( PDI7vec & )"));
}

void G4cfgDlg::OnBnClickedButton11()	// ResetFrameOfRef( )
{
	m_pg4->ResetFrameOfRef();
	m_pParent->AddResultMsg( _T("ResetFrameOfRef"));

	OnBnClickedButton9();
}

void G4cfgDlg::EnableDlgItems()
{
	m_edtFORrotQ3.EnableWindow( m_nCmdOriUnits == E_PDI_ORI_QUATERNION );
	m_edtFiltersCmdHub.EnableWindow( !m_bFiltersAllHubs );
	m_edtSCmdHub.EnableWindow( !m_bSCmdAllHubs );
	m_edtSCmdSens.EnableWindow( !m_bSCmdAllHubs );
	m_edtBore3.EnableWindow( m_nCmdOriUnits == E_PDI_ORI_QUATERNION );
	
}

void G4cfgDlg::OnCbnSelchangeCombo1()	// SetCmdPosUnits( )
{
	UpdateData();
	m_pg4->SetCmdPosUnits( (ePDIposUnits) m_nCmdPosUnits );
	m_pParent->AddMsg( CString(_T("CmdSetPosUnits()\r\n")) );
}

void G4cfgDlg::OnCbnSelchangeCombo2()	// SetCmdOriUnits( )
{
	UpdateData();
	m_pg4->SetCmdOriUnits( (ePDIoriUnits) m_nCmdOriUnits );
	m_pParent->AddMsg( CString(_T("CmdSetOriUnits()\r\n")) );
	EnableDlgItems();
}

void G4cfgDlg::OnBnClickedCheck1()
{
	UpdateData();
	EnableDlgItems();
}

void G4cfgDlg::OnBnClickedButton1()	// GetHAttFilter( )
{
	UpdateData();
	m_pg4->GetHAttFilter( m_nFiltersCmdHub, m_AttFilter );
	m_pParent->AddResultMsg(_T("GetHAttFilter"));
	UpdateData(FALSE);
}

void G4cfgDlg::OnBnClickedButton2() // SetHAttFilter( )
{
	UpdateData();
	m_pg4->SetHAttFilter( (m_bFiltersAllHubs) ? PDI_ALL_DEVICES : m_nFiltersCmdHub, m_AttFilter );
	m_pParent->AddResultMsg(_T("SetHAttFilter"));
}

void G4cfgDlg::OnBnClickedButton3() // ResetHAttFilter( )
{
	UpdateData();
	m_pg4->ResetHAttFilter( (m_bFiltersAllHubs) ? PDI_ALL_DEVICES : m_nFiltersCmdHub );
	m_pParent->AddResultMsg(_T("ResetHAttFilter"));

	OnBnClickedButton1();
}

void G4cfgDlg::OnBnClickedButton12() // GetHPosFilter( )
{
	UpdateData();
	m_pg4->GetHPosFilter( m_nFiltersCmdHub, m_PosFilter );
	m_pParent->AddResultMsg(_T("GetHPosFilter"));
	UpdateData(FALSE);
}

void G4cfgDlg::OnBnClickedButton13() // SetHPosFilter( )
{
	UpdateData();
	m_pg4->SetHPosFilter( (m_bFiltersAllHubs) ? PDI_ALL_DEVICES : m_nFiltersCmdHub, m_PosFilter );
	m_pParent->AddResultMsg(_T("SetHPosFilter"));
}

void G4cfgDlg::OnBnClickedButton6()	// ResetHPosFilter( )
{
	UpdateData();
	m_pg4->ResetHPosFilter( (m_bFiltersAllHubs) ? PDI_ALL_DEVICES : m_nFiltersCmdHub );
	m_pParent->AddResultMsg(_T("ResetHPosFilter"));

	OnBnClickedButton12();
}

void G4cfgDlg::InitializeDisplayedSettings(void)
{
	OnBnClickedButton9();	// GetFrameOfRef( PDI7vec & )
	OnBnClickedButton7();	// GetHFilters( )
	OnBnClickedButton15();	// GetSIncrement( )
	OnBnClickedButton18();	// GetSBoresight( PDI4vec & )
	OnBnClickedButton21();	// GetSTipOffset( )
}


void G4cfgDlg::OnBnClickedButton7()  // GetHFilters( )
{
	UpdateData();
	m_pg4->GetHFilters( m_nFiltersCmdHub, m_AttFilter, m_PosFilter );
	m_pParent->AddResultMsg(_T("GetHFilters"));
	UpdateData(FALSE);
}

void G4cfgDlg::OnBnClickedButton8()	// SetHFilters( )
{
	UpdateData();
	m_pg4->SetHFilters( (m_bFiltersAllHubs) ? PDI_ALL_DEVICES : m_nFiltersCmdHub, m_AttFilter, m_PosFilter );
	m_pParent->AddResultMsg(_T("SetHFilters"));
}

void G4cfgDlg::OnBnClickedButton14()	// ResetHFilters( )
{
	UpdateData();
	m_pg4->ResetHFilters( (m_bFiltersAllHubs) ? PDI_ALL_DEVICES : m_nFiltersCmdHub );
	m_pParent->AddResultMsg(_T("ResetHFilters"));

	OnBnClickedButton7();
}

void G4cfgDlg::OnBnClickedButton15()	// GetSIncrement( )
{
	UpdateData();
	m_pg4->GetSIncrement( m_nSCmdHub, m_nSCmdSens, m_fPosIncr, m_fOriIncr );
	m_pParent->AddResultMsg(_T("GetSIncrement"));
	UpdateData(FALSE);
}

void G4cfgDlg::OnBnClickedButton16()	// SetSIncrement()
{
	UpdateData();
	m_pg4->SetSIncrement( (m_bSCmdAllHubs) ? PDI_ALL_DEVICES : m_nSCmdHub, m_nSCmdSens, m_fPosIncr, m_fOriIncr );
	m_pParent->AddResultMsg(_T("SetSIncrement"));
	
}

void G4cfgDlg::OnBnClickedButton17()	// ResetSIncrement()
{
	UpdateData();
	m_pg4->ResetSIncrement( (m_bSCmdAllHubs) ? PDI_ALL_DEVICES : m_nSCmdHub, m_nSCmdSens );
	m_pParent->AddResultMsg(_T("ResetSIncrement"));

	OnBnClickedButton15();
}

void G4cfgDlg::OnBnClickedCheck2()	// Sensor Command All Hubs Checked
{
	UpdateData();
	EnableDlgItems();
}

void G4cfgDlg::OnBnClickedButton18()	// GetSBoresight( PDI4vec & )
{
	UpdateData();
	
	m_pg4->GetSBoresight( m_nSCmdHub, m_nSCmdSens, m_vBore );
	m_pParent->AddResultMsg(_T("GetSBoresight( PDI4vec & )"));
	UpdateData(FALSE);
}

void G4cfgDlg::OnBnClickedButton19()	// SetSBoresight( PDI4vec & )
{
	UpdateData();
	m_pg4->SetSBoresight( (m_bSCmdAllHubs) ? PDI_ALL_DEVICES : m_nSCmdHub, m_nSCmdSens, m_vBore );
	m_pParent->AddResultMsg(_T("SetSBoresight( PDI4vec & )"));

}

void G4cfgDlg::OnBnClickedButton20()	// ResetSBoresight( )
{
	UpdateData();
	m_pg4->ResetSBoresight( (m_bSCmdAllHubs) ? PDI_ALL_DEVICES : m_nSCmdHub, m_nSCmdSens );
	m_pParent->AddResultMsg(_T("ResetSBoresight( )"));

	OnBnClickedButton18();
}

void G4cfgDlg::OnBnClickedButton21()	// GetSTipOffset( )
{
	UpdateData();
	m_pg4->GetSTipOffset( (m_bSCmdAllHubs) ? PDI_ALL_DEVICES : m_nSCmdHub, m_nSCmdSens, m_vTipOffset );
	m_pParent->AddResultMsg(_T("GetSTipOffset( )"));
	UpdateData(FALSE);
}

void G4cfgDlg::OnBnClickedButton22()	// SetSTipOffset( )
{
	UpdateData();
	m_pg4->SetSTipOffset( (m_bSCmdAllHubs) ? PDI_ALL_DEVICES : m_nSCmdHub, m_nSCmdSens, m_vTipOffset );
	m_pParent->AddResultMsg(_T("SetSTipOffset( )"));
}

void G4cfgDlg::OnBnClickedButton23()
{
	UpdateData();
	m_pg4->ResetSTipOffset( (m_bSCmdAllHubs) ? PDI_ALL_DEVICES : m_nSCmdHub, m_nSCmdSens );
	m_pParent->AddResultMsg(_T("ResetSTipOffset( )"));

	OnBnClickedButton21();	// GetSTipOffset( )
}
