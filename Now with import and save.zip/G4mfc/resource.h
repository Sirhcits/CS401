//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by G4mfc.rc
//
#define IDD_G4MFC_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDD_G4MFC_CONFIG                130
#define IDD_DIALOG1                     132
#define IDC_CHECK1                      1000
#define IDC_EDIT1                       1001
#define IDC_BUTTON1                     1002
#define IDC_BUTTON2                     1003
#define IDC_EDIT2                       1004
#define IDC_EDIT3                       1005
#define IDC_EDIT4                       1006
#define IDC_BUTTON3                     1007
#define IDC_BUTTON4                     1008
#define IDC_EDIT12                      1008
#define IDC_BUTTON5                     1009
#define IDC_EDIT13                      1009
#define IDC_RADIO1                      1010
#define IDC_EDIT14                      1010
#define IDC_BUTTON26                    1010
#define IDC_RADIO2                      1011
#define IDC_EDIT15                      1011
#define IDC_RADIO3                      1012
#define IDC_BUTTON12                    1012
#define IDC_RADIO4                      1013
#define IDC_BUTTON13                    1013
#define IDC_BUTTON6                     1014
#define IDC_BUTTON7                     1015
#define IDC_BUTTON8                     1016
#define IDC_RADIO5                      1017
#define IDC_RADIO6                      1018
#define IDC_RADIO7                      1019
#define IDC_BUTTON25                    1019
#define IDC_BUTTON9                     1020
#define IDC_BUTTON10                    1021
#define IDC_EDIT5                       1022
#define IDC_EDIT6                       1023
#define IDC_EDIT7                       1024
#define IDC_EDIT8                       1025
#define IDC_EDIT9                       1026
#define IDC_EDIT10                      1027
#define IDC_EDIT11                      1028
#define IDC_BUTTON11                    1029
#define IDC_CHECK2                      1030
#define IDC_BUTTON24                    1030
#define IDC_COMBO1                      1031
#define IDC_COMBO2                      1032
#define IDC_EDIT16                      1034
#define IDC_BUTTON14                    1035
#define IDC_EDIT18                      1037
#define IDC_EDIT19                      1038
#define IDC_BUTTON15                    1039
#define IDC_BUTTON16                    1040
#define IDC_BUTTON17                    1041
#define IDC_EDIT20                      1043
#define IDC_EDIT21                      1044
#define IDC_EDIT22                      1046
#define IDC_EDIT23                      1047
#define IDC_EDIT24                      1048
#define IDC_EDIT25                      1049
#define IDC_BUTTON18                    1050
#define IDC_BUTTON19                    1051
#define IDC_BUTTON20                    1052
#define IDC_EDIT26                      1053
#define IDC_EDIT27                      1054
#define IDC_EDIT28                      1055
#define IDC_BUTTON21                    1056
#define IDC_BUTTON22                    1057
#define IDC_BUTTON23                    1058
#define IDC_CHECK3                      1059
#define IDC_LIST1                       1060
#define IDC_LIST2                       1061

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1071
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
